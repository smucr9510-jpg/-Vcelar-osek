# Včelař – Osek 5.0

Offline-first Android/iOS app for apiary records at TORENO, Osek.

## Version 5 changes
- Uses the supplied realistic honeybee-on-honeycomb image for app icons and launcher assets.
- Backup export uses Capacitor Filesystem + Share plugins, bundled with esbuild so the native plugins are actually registered in the app.
- LPIS parcel geometries are rendered in a local SVG map after WFS import; tapping a parcel opens its card.
- Parcel boundaries and attributes are kept in local storage for offline viewing. Crop and flowering details remain unconfirmed unless manually verified.
- Android application ID: `cz.toreno.vcelarosek5` (installs alongside earlier versions).

## Build
Run `npm install`, copy web assets to `www`, bundle `app.js` with esbuild to `www/app.bundle.js`, run `npx cap add android`, `npx capacitor-assets generate --android`, `npx cap sync android`, then `./gradlew assembleDebug` in `android`.

LPIS WFS requires an internet connection for initial import and may be limited by the public service's CORS policy. No server proxy is included.
