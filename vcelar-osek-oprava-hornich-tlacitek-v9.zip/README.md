# Včelař – Osek (zdrojový projekt v8)

Tento projekt vychází z webových souborů uvnitř uživatelem dodané funkční instalační verze 7.
Byla zachována původní navigace, evidence, lokální úložiště, exportní logika verze 7 a offline režim.
Jediná úprava aplikace v této iteraci: rozšíření rozpoznání identifikátoru LPIS `IdDiluPudnihoBloku`.

## Sestavení Android APK
1. Nahrajte celý obsah tohoto ZIP do kořenové složky GitHub repozitáře `smucr9510-jpg/-Vcelar-osek`.
2. Zachovejte složku `.github/workflows`.
3. Po nahrání souborů spusťte GitHub Actions workflow `Build Android APK`.
4. APK bude v artefaktu `vcelar-osek-android`.

## Důležité
- Tento ZIP je zdrojový projekt, nikoli instalační APK.
- `appId` je zachováno jako `cz.toreno.vcelarosek2`.
- Funkční verzi 7 v telefonu ponechte jako zálohu. Neodinstalovávejte ji a nemažte její data.
- LPIS import je zatím přímé WFS volání; CORS a konkrétní parametry služby je nutné ověřit v reálném běhu.
