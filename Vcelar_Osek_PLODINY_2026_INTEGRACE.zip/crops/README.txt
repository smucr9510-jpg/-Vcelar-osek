Včelař – Osek: deklarované plodiny LPIS 2026
Zdroj: GPZ_DP_2026-08-01_epsg5514.zip (veřejný export MZe/SZIF)
Platnost dat: 1. 8. 2026. Souřadnice GeoJSON převedeny do EPSG:4326.
Výběr: geometrie deklarací protínající kruh o poloměru 5 000 m kolem stanoviště TORENO, Osek (49.7804535 N, 13.5998565 E).
Počet deklarací: 380; unikátní DPB: 296.
Pozor: jedna parcela může mít více deklarací/plodin; nejde o živý stav k dnešnímu dni.
