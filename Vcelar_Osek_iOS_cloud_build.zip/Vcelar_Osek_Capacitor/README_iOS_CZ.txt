VČELAŘ – OSEK | iOS PODPORA

Tento balíček doplňuje společný projekt Včelař – Osek o přípravu iOS platformy a cloudové sestavení pro iOS Simulator.

CO JE UVNITŘ
- Stejná webová aplikace jako v Android balíčku (evidence včelstev, kontroly, pastva, pozemky, záloha a LPIS rozhraní).
- Doplněné iOS meta značky pro zobrazení po přidání na plochu iPhonu.
- Workflow .github/workflows/ios-simulator.yml, které na GitHubu vytvoří aplikaci pro iOS Simulator.

DŮLEŽITÉ ROZLIŠENÍ
- Výstup iOS Simulator je určen pouze pro simulátor v Xcode. NELZE jej nainstalovat do běžného iPhonu.
- Pro instalaci na fyzický iPhone je potřeba podepsat aplikaci certifikátem a provisioning profilem Apple.
- Standardní distribuce přes TestFlight vyžaduje Apple Developer Program a App Store Connect.
- Tento balíček sám o sobě není hotová IPA a neobsahuje Apple podpisové certifikáty.

CLOUDOVÉ OVĚŘENÍ
1. Nahraj obsah projektu do stejného GitHub repozitáře jako Android verzi. Pokud už tam Android projekt je, nahraj pouze nové soubory a složky z tohoto balíčku a zachovej existující soubory.
2. Zkontroluj, že je nahrána skrytá složka .github/workflows a soubor ios-simulator.yml.
3. Otevři v GitHubu záložku Actions.
4. Vyber Build iOS Simulator app a spusť Run workflow, nebo nech sestavení proběhnout po pushi.
5. Po dokončení běhu stáhni artifact vcelar-osek-ios-simulator. Je to pouze simulátorová verze pro technické ověření.

POZNÁMKA K DATŮM
Data jsou v této verzi ukládána lokálně v úložišti aplikace/prohlížeče. Android a iOS si data automaticky nesynchronizují. Před běžným používáním pravidelně exportuj JSON zálohu a bezpečně ji ulož.
