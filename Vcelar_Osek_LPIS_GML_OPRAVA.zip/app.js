import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';
'use strict';
const SITE={name:'TORENO, s.r.o., Osek 489',lat:49.7804535,lon:13.5998565};
const KEY='vcelarOsek.data.v2';
const $=id=>document.getElementById(id);const today=()=>new Date().toISOString().slice(0,10);const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const seed=()=>({colonies:[1,2,3,4].map(n=>({id:'seed'+n,name:'Úl '+n,type:'Adamec 11 rámků',date:'',state:'Aktivní',notes:''})),checks:[],forage:[],parcels:[],updated:new Date().toISOString()});
let db;try{db=JSON.parse(localStorage.getItem(KEY)||'null')}catch{db=null}if(!db||!Array.isArray(db.colonies))db=seed();
function save(){db.updated=new Date().toISOString();try{localStorage.setItem(KEY,JSON.stringify(db))}catch(e){alert('Nepodařilo se uložit data. Zkontrolujte volné místo v telefonu.');}renderAll()}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function page(id){const target=$(id);if(!target||!target.classList.contains('page'))return;document.querySelectorAll('main .page').forEach(x=>x.classList.toggle('hidden',x!==target));document.querySelectorAll('#nav button[data-page]').forEach(x=>{const active=x.dataset.page===id;x.classList.toggle('active',active);x.setAttribute('aria-current',active?'page':'false')});if(id==='checks')fillColonySelect();if(id==='parcels')renderParcelMap()}
// Android WebView-safe direct handlers: each navigation button owns its own click listener.
document.querySelectorAll('#nav button[data-page]').forEach(button=>{button.type='button';button.addEventListener('click',event=>{event.preventDefault();page(button.dataset.page)},{passive:false});});
function renderColonies(){ $('colonyList').innerHTML=db.colonies.map(c=>`<div class="item"><div><b>${esc(c.name)}</b><div class="muted">${esc(c.type||'Typ neuveden')} · ${esc(c.state)}</div><div class="small">${esc(c.notes)}</div></div><button class="btn" data-edit-col="${esc(c.id)}">Upravit</button></div>`).join('')||'<div class="empty">Zatím žádná včelstva.</div>';fillColonySelect() }
function fillColonySelect(){let s=$('checkColony'),old=s.value;s.innerHTML=db.colonies.map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('');if(old)s.value=old}
function clearColony(){['colId','colName','colType','colDate','colNotes'].forEach(x=>$(x).value='');$('colState').value='Aktivní'}
$('newColony').onclick=clearColony;$('cancelColony').onclick=clearColony;
$('colonyList').onclick=e=>{let b=e.target.closest('[data-edit-col]');if(!b)return;let c=db.colonies.find(x=>x.id===b.dataset.editCol);if(!c)return;$('colId').value=c.id;$('colName').value=c.name;$('colType').value=c.type;$('colDate').value=c.date;$('colState').value=c.state;$('colNotes').value=c.notes;page('colonies');$('colName').focus()};
$('saveColony').onclick=()=>{let c={id:$('colId').value||uid(),name:$('colName').value.trim()||'Nové včelstvo',type:$('colType').value,date:$('colDate').value,state:$('colState').value,notes:$('colNotes').value};let i=db.colonies.findIndex(x=>x.id===c.id);if(i<0)db.colonies.push(c);else db.colonies[i]=c;clearColony();save()};
$('checkDate').value=today();$('forDate').value=today();
$('saveCheck').onclick=()=>{if(!db.colonies.length){alert('Nejprve přidejte včelstvo.');return}db.checks.unshift({id:uid(),date:$('checkDate').value||today(),colony:$('checkColony').value,type:$('checkType').value,varroa:$('checkVarroa').value,action:$('checkAction').value,notes:$('checkNotes').value});['checkVarroa','checkAction','checkNotes'].forEach(x=>$(x).value='');save()};
function renderChecks(){$('checkList').innerHTML=db.checks.map(c=>{let n=db.colonies.find(x=>x.id===c.colony)?.name||'Včelstvo';return `<div class="item"><div><b>${esc(c.date)} · ${esc(n)}</b><div><span class="tag">${esc(c.type)}</span></div><div>${esc(c.action)}</div><div class="muted">${esc(c.varroa)} ${esc(c.notes)}</div></div><button class="btn danger" data-del-check="${esc(c.id)}">Smazat</button></div>`}).join('')||'<div class="empty">Zatím žádné kontroly.</div>'}
$('checkList').onclick=e=>{let b=e.target.closest('[data-del-check]');if(b&&confirm('Smazat tento záznam kontroly?')){db.checks=db.checks.filter(x=>x.id!==b.dataset.delCheck);save()}};
$('saveForage').onclick=()=>{if(!$('forPlant').value.trim()){alert('Vyplňte rostlinu nebo plodinu.');return}db.forage.unshift({id:uid(),date:$('forDate').value||today(),radius:$('forRadius').value,plant:$('forPlant').value,phase:$('forPhase').value,flow:$('forFlow').value,weather:$('forWeather').value,notes:$('forNotes').value});['forPlant','forWeather','forNotes'].forEach(x=>$(x).value='');save()};
function renderForage(){$('forageList').innerHTML=db.forage.map(f=>`<div class="item"><div><b>${esc(f.date)} · ${esc(f.plant)}</b><div><span class="tag">${esc(f.radius)}</span><span class="tag">${esc(f.phase)}</span><span class="tag">Snůška: ${esc(f.flow)}</span></div><div class="muted">${esc(f.weather)} ${esc(f.notes)}</div></div><button class="btn danger" data-del-for="${esc(f.id)}">Smazat</button></div>`).join('')||'<div class="empty">Zatím bez pozorování pastvy.</div>'}
$('forageList').onclick=e=>{let b=e.target.closest('[data-del-for]');if(b&&confirm('Smazat pozorování?')){db.forage=db.forage.filter(x=>x.id!==b.dataset.delFor);save()}};
let openParcelId=null;const parcelForm=$('parcelForm'),parcelFormHome=parcelForm.parentNode,parcelFormAnchor=parcelForm.nextSibling;
function restoreParcelForm(){if(parcelForm.parentNode!==parcelFormHome)parcelFormHome.insertBefore(parcelForm,parcelFormAnchor)}
function fillParcelForm(p){let map={code:'pCode',dist:'pDist',area:'pArea',culture:'pCulture',crop:'pCrop',status:'pStatus',from:'pFrom',to:'pTo',bee:'pBee',verified:'pVerified',notes:'pNotes'};$('pId').value=p.id;Object.entries(map).forEach(([k,v])=>$(v).value=p[k]??'');$('deleteParcel').classList.remove('hidden');$('parcelHeading').textContent='Karta pozemku '+(p.code||'')}
function clearParcel(){openParcelId=null;restoreParcelForm();['pId','pCode','pDist','pArea','pCulture','pCrop','pFrom','pTo','pVerified','pNotes'].forEach(x=>$(x).value='');$('pStatus').value='Neznámé';$('pBee').value='Neurčeno';$('deleteParcel').classList.add('hidden');$('parcelHeading').textContent='Karta pozemku';parcelForm.classList.remove('inline-parcel-card')}
function editParcel(id){let p=db.parcels.find(x=>x.id===id);if(!p)return;openParcelId=id;renderParcels()}
$('newParcel').onclick=()=>{clearParcel();parcelForm.scrollIntoView({behavior:'smooth',block:'start'});$('pCode').focus({preventScroll:true})};$('clearParcel').onclick=()=>{if(openParcelId){openParcelId=null;clearParcel();renderParcels()}else clearParcel()};
$('saveParcel').onclick=()=>{let p={id:$('pId').value||uid(),code:$('pCode').value.trim(),dist:$('pDist').value,area:$('pArea').value,culture:$('pCulture').value,crop:$('pCrop').value,status:$('pStatus').value,from:$('pFrom').value,to:$('pTo').value,bee:$('pBee').value,verified:$('pVerified').value,notes:$('pNotes').value};if(!p.code&&!p.crop){alert('Vyplňte alespoň LPIS ID nebo plodinu.');return}let i=db.parcels.findIndex(x=>x.id===p.id);if(i<0)db.parcels.push(p);else db.parcels[i]={...db.parcels[i],...p};openParcelId=p.id;save()};
$('deleteParcel').onclick=()=>{let id=$('pId').value;if(id&&confirm('Opravdu smazat pozemek?')){db.parcels=db.parcels.filter(x=>x.id!==id);openParcelId=null;restoreParcelForm();clearParcel();save()}};
function renderParcelMap(){const host=$('parcelMap');if(!host)return;const items=db.parcels.filter(p=>p.geometry&&p.geometry.coordinates);if(!items.length){host.innerHTML='<div class="empty">Po načtení hranic LPIS se zde zobrazí mapa pozemků. Kliknutím na plochu otevřete kartu.</div>';return}let pts=[];const rings=[];for(const p of items){const g=p.geometry;let polys=g.type==='Polygon'?[g.coordinates]:g.type==='MultiPolygon'?g.coordinates:[];for(const poly of polys){const ring=poly[0]||[];if(ring.length>2){rings.push({id:p.id,code:p.code,ring});pts.push(...ring)}}}if(!pts.length){host.textContent='Načtené prvky neobsahují podporovanou geometrii.';return}const xs=pts.map(x=>x[0]),ys=pts.map(x=>x[1]),minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys),dx=maxX-minX||1,dy=maxY-minY||1;const project=([x,y])=>[18+(x-minX)/dx*564,382-(y-minY)/dy*364];host.innerHTML='<svg viewBox="0 0 600 400" role="img" aria-label="Mapa importovaných LPIS pozemků">'+rings.map(r=>{const d=r.ring.map((c,i)=>{const q=project(c);return(i?'L':'M')+q[0].toFixed(1)+' '+q[1].toFixed(1)}).join(' ')+' Z';return '<path d="'+d+'" fill="#d6ad50" fill-opacity=".45" stroke="#77501b" stroke-width="1.5" data-map-parcel="'+esc(r.id)+'"><title>'+esc(r.code||'Pozemek')+'</title></path>'}).join('')+'</svg><p class="muted">Zobrazeny jsou pouze hranice uložené z LPIS. Klepnutím na pozemek otevřete jeho kartu.</p>';host.querySelectorAll('[data-map-parcel]').forEach(el=>el.addEventListener('click',()=>editParcel(el.getAttribute('data-map-parcel'))))}
function renderParcels(){let q=$('parcelSearch').value.toLowerCase();let rows=db.parcels.filter(p=>JSON.stringify(p).toLowerCase().includes(q));$('parcelList').innerHTML=rows.map(p=>`<div class="parcel-entry"><div class="item"><div><b>${esc(p.code||'Pozemek bez ID')}</b><div class="muted">${esc(p.crop||p.culture||'Plodina neznámá')} · ${p.area?esc(p.area)+' ha':'výměra neuvedena'}</div><span class="tag">${esc(p.status)}</span></div><button type="button" class="btn" data-edit-parcel="${esc(p.id)}">${openParcelId===p.id?'Zavřít kartu':'Karta'}</button></div>${openParcelId===p.id?'<div class="parcel-card-slot" id="parcelCardSlot"></div>':''}</div>`).join('')||'<div class="empty">Evidence je prázdná. Pozemek přidejte ručně nebo načtěte z LPIS.</div>';if(openParcelId){let p=db.parcels.find(x=>x.id===openParcelId),slot=$('parcelCardSlot');if(p&&slot){slot.appendChild(parcelForm);parcelForm.classList.add('inline-parcel-card');fillParcelForm(p)}}else restoreParcelForm();renderParcelMap()}
$('parcelSearch').oninput=()=>{if(openParcelId&&!db.parcels.some(p=>p.id===openParcelId))openParcelId=null;renderParcels()};$('parcelList').onclick=e=>{let b=e.target.closest('[data-edit-parcel]');if(b){let id=b.dataset.editParcel;if(openParcelId===id){openParcelId=null;clearParcel()}else openParcelId=id;renderParcels()}};
function renderHome(){$('sColonies').textContent=db.colonies.length;$('sChecks').textContent=db.checks.length;$('sParcels').textContent=db.parcels.length;$('sForage').textContent=db.forage.length;let all=[...db.checks.map(x=>({...x,label:'Kontrola · '+(db.colonies.find(c=>c.id===x.colony)?.name||'Včelstvo'),detail:x.type})),...db.forage.map(x=>({...x,label:'Pastva · '+x.plant,detail:x.flow}))].sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,5);$('recent').innerHTML=all.map(x=>`<div class="item"><div><b>${esc(x.date)} · ${esc(x.label)}</b><div class="muted">${esc(x.detail)}</div></div></div>`).join('')||'<div class="empty">Zatím bez záznamů.</div>'}
function renderAll(){renderColonies();renderChecks();renderForage();renderParcels();renderHome()}
function wfsStatus(msg,bad=false){$('wfsStatus').className='notice'+(bad?' bad':'');$('wfsStatus').textContent=msg}
function endpoint(){return $('wfsUrl').value.trim().replace(/\?+$/,'')}
$('openCaps').onclick=()=>window.open(endpoint()+'?service=WFS&request=GetCapabilities','_blank');
$('getCaps').onclick=async()=>{
 if(!navigator.onLine){wfsStatus('Jste offline. Uložené pozemky jsou dostupné; pro načtení aktuálních dat LPIS se připojte k internetu.',true);return}
 wfsStatus('Ověřuji veřejnou službu LPIS Ministerstva zemědělství…');
 try{
  const u=new URL(endpoint());u.searchParams.set('SERVICE','WFS');u.searchParams.set('VERSION','1.0.0');u.searchParams.set('REQUEST','GetCapabilities');
  const r=await fetch(u,{cache:'no-store'});if(!r.ok)throw Error('HTTP '+r.status);
  const xml=new DOMParser().parseFromString(await r.text(),'text/xml');if(xml.querySelector('parsererror'))throw Error('Služba nevrátila platné XML');
  const names=[...xml.getElementsByTagNameNS('*','FeatureType')].map(n=>({name:n.getElementsByTagNameNS('*','Name')[0]?.textContent,title:n.getElementsByTagNameNS('*','Title')[0]?.textContent}));
  const layer=names.find(x=>/LPIS_DPB_UCINNE$/i.test(x.name||''));
  if(!layer)throw Error('Ve službě nebyla nalezena vrstva LPIS_DPB_UCINNE');
  $('wfsLayer').innerHTML=`<option value="${esc(layer.name)}">${esc(layer.title||'Účinné díly půdních bloků')} (${esc(layer.name)})</option>`;
  wfsStatus('Spojení navázáno. Vybrána aktuální vrstva účinných dílů půdních bloků.');
 }catch(e){wfsStatus('LPIS se nepodařilo ověřit: '+e.message+'. Pokud se objeví chyba CORS, bude nutné zprostředkování požadavku přes proxy; přímý přístup z telefonu není službou povolen.',true)}
};
$('getFeatures').onclick=async()=>{
 const layer=$('wfsLayer').value;if(!layer){wfsStatus('Nejdříve ověřte spojení s LPIS.',true);return}
 if(!navigator.onLine){wfsStatus('Jste offline. Import LPIS není dostupný.',true);return}
 try{
  const proj=await import('proj4');const p4=proj.default||proj;
  const from='EPSG:5514',to='EPSG:4326';
  p4.defs(from,'+proj=krovak +lat_0=49.5 +lon_0=24.8333333333333 +alpha=30.2881397527778 +k=0.9999 +x_0=0 +y_0=0 +ellps=bessel +pm=greenwich +units=m +no_defs +towgs84=570.69,85.69,462.84,4.998,1.587,5.261,3.56');
  const center=p4(to,from,[SITE.lon,SITE.lat]);const radius=6500;
  const u=new URL(endpoint());const params={SERVICE:'WFS',VERSION:'1.0.0',REQUEST:'GetFeature',TYPENAME:layer,SRSNAME:from,BBOX:[center[0]-radius,center[1]-radius,center[0]+radius,center[1]+radius,from].join(','),MAXFEATURES:$('wfsLimit').value};
  Object.entries(params).forEach(([k,v])=>u.searchParams.set(k,v));wfsStatus('Načítám LPIS ve formátu GML v okolí stanoviště…');
  const r=await fetch(u,{cache:'no-store'});if(!r.ok)throw Error('HTTP '+r.status);
  const raw=await r.text();const xml=new DOMParser().parseFromString(raw,'text/xml');if(xml.querySelector('parsererror'))throw Error('Odpověď WFS není platné XML');
  const exception=xml.getElementsByTagNameNS('*','ServiceException');if(exception.length)throw Error('LPIS: '+exception[0].textContent.trim().slice(0,240));
  const members=[...xml.getElementsByTagNameNS('*','featureMember'),...xml.getElementsByTagNameNS('*','member')];
  if(!members.length)throw Error('WFS nevrátilo žádné prvky. Zkontrolujte vrstvu a parametry požadavku.');
  const local=n=>(n.localName||n.nodeName.split(':').pop()).toLowerCase();
  const childText=(node,keys)=>{for(const el of [...node.getElementsByTagName('*')])if(keys.includes(local(el)))return el.textContent.trim();return ''};
  const parseRing=ring=>{
   const c=[...ring.getElementsByTagNameNS('*','coordinates')][0];
   if(c)return c.textContent.trim().split(/\s+/).map(pair=>pair.split(',').slice(0,2).map(Number)).filter(x=>x.length===2&&x.every(Number.isFinite));
   const pos=[...ring.getElementsByTagNameNS('*','posList')][0];if(pos){const vals=pos.textContent.trim().split(/\s+/).map(Number),dim=Number(pos.getAttribute('srsDimension')||2),out=[];for(let i=0;i+1<vals.length;i+=dim)out.push(vals.slice(i,i+2));return out.filter(x=>x.every(Number.isFinite))}
   const positions=[...ring.getElementsByTagNameNS('*','pos')];return positions.map(x=>x.textContent.trim().split(/\s+/).map(Number).slice(0,2)).filter(x=>x.length===2&&x.every(Number.isFinite));
  };
  const geometryOf=feature=>{
   const polygons=[...feature.getElementsByTagNameNS('*','Polygon')];const multi=[];
   for(const poly of polygons){const rings=[...poly.getElementsByTagNameNS('*','LinearRing')].map(parseRing).filter(x=>x.length>=4);if(rings.length)multi.push(rings.map(r=>r.map(c=>p4(from,to,c))))}
   if(!multi.length)return null;return multi.length===1?{type:'Polygon',coordinates:multi[0]}:{type:'MultiPolygon',coordinates:multi};
  };
  const features=[];for(const m of members){const feature=[...m.children].find(x=>x.nodeType===1);if(!feature)continue;const geometry=geometryOf(feature);if(!geometry)continue;const props={};for(const el of [...feature.children]){const k=local(el);if(!['geometry','geom','shape','the_geom'].includes(k)&&!el.getElementsByTagNameNS('*','Polygon').length)props[el.localName||k]=el.textContent.trim()}features.push({geometry,properties:props})}
  if(!features.length)throw Error('WFS odpovědělo XML, ale nepodařilo se v něm najít hranice pozemků.');
  let added=0,updated=0,outside=0;
  const coordsOf=g=>{const out=[];const walk=v=>{if(Array.isArray(v)&&typeof v[0]==='number'&&typeof v[1]==='number')out.push(v);else if(Array.isArray(v))v.forEach(walk)};walk(g.coordinates);return out};
  for(const f of features){
   const a=f.properties;
   const find=(...keys)=>{const wanted=keys.map(x=>x.toLowerCase());for(const [k,v] of Object.entries(a))if(wanted.includes(k.toLowerCase()))return v;return ''};
   const dpb=find('IdDiluPudnihoBloku','idDpb','ID_DPB'),short=find('zkracenyKod','zkraceny_kod');const code=short||dpb||'DPB bez kódu';
   const coords=coordsOf(f.geometry);const center=coords.reduce((v,c)=>[v[0]+c[0]/coords.length,v[1]+c[1]/coords.length],[0,0]);
   const dist=Math.round(Math.hypot((center[0]-SITE.lon)*111320*Math.cos(SITE.lat*Math.PI/180),(center[1]-SITE.lat)*111320));if(dist>5600){outside++;continue}
   const key=String(dpb||short||JSON.stringify(f.geometry));const existing=db.parcels.find(p=>p.sourceKey===key);
   let area=Number(String(find('vymera','VYMERA')).replace(',','.'));if(Number.isFinite(area)&&area>10000)area/=10000;
   const fields={code:String(code),dist:String(dist),area:Number.isFinite(area)&&area>0?area.toFixed(2):'',culture:String(find('kultura','KULTURA')),crop:'',status:'LPIS – aktuální data',from:'',to:'',bee:'Neurčeno',geometry:f.geometry,sourceKey:key,attributes:a,notes:'Údaje převzaty z veřejné WFS LPIS. Plodina není v této vrstvě spolehlivě poskytována; doplňte ji pouze po ověření.'};
   if(existing){Object.assign(existing,fields);updated++}else{db.parcels.push({id:uid(),...fields,verified:today()});added++}
  }
  save();wfsStatus(`LPIS vrátilo ${features.length} prvků. Nově uloženo: ${added}, aktualizováno: ${updated}. Mimo okolí: ${outside}. Hranice a dostupné údaje jsou uložené offline.`);
 }catch(e){wfsStatus('Načtení LPIS selhalo: '+e.message+'. Pokud telefon hlásí CORS, bude nutné zprostředkování požadavku; stávající data v telefonu zůstávají zachována.',true)}
};
$('export').onclick=async()=>{const json=JSON.stringify({app:'Včelař – Osek',version:5,exported:new Date().toISOString(),site:SITE,data:db},null,2);const name='vcelar-osek-zaloha-'+today()+'.json';const status=$('backupStatus');status.textContent='Připravuji záložní soubor…';try{const bytes=new TextEncoder().encode(json);let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));const base64=btoa(binary);const saved=await Filesystem.writeFile({path:name,data:base64,directory:Directory.Cache,recursive:true});await Share.share({title:'Záloha Včelař – Osek',text:'Záložní soubor '+name,url:saved.uri,dialogTitle:'Uložit nebo sdílet zálohu'});status.textContent='Záložní soubor byl vytvořen v dočasném úložišti a předán ke sdílení. Uložte jej do telefonu nebo cloudu: '+name;}catch(e){status.textContent='Zálohu se nepodařilo uložit. '+(e.message||String(e))+'; data v aplikaci zůstala zachována.';}};
$('importFile').onchange=async e=>{let f=e.target.files[0];if(!f)return;try{let obj=JSON.parse(await f.text()),d=obj.data||obj;if(!Array.isArray(d.colonies)||!Array.isArray(d.checks)||!Array.isArray(d.parcels)||!Array.isArray(d.forage))throw Error('Soubor nemá správnou strukturu zálohy.');if(!confirm('Import nahradí současná data v tomto telefonu. Pokračovat?'))return;db=d;save();$('backupStatus').textContent='Záloha byla úspěšně importována.'}catch(err){$('backupStatus').textContent='Import se nezdařil: '+err.message}e.target.value=''};
$('resetData').onclick=()=>{if(confirm('Opravdu trvale vymazat všechna data aplikace v tomto zařízení? Doporučujeme nejprve exportovat zálohu.')){db=seed();save();$('backupStatus').textContent='Data byla vymazána a obnovena výchozí čtyři včelstva.'}};
function net(){let on=navigator.onLine;$('net').textContent=on?'Aplikace připravena · online':'Offline režim · data v telefonu';$('net').classList.toggle('no',!on)}window.addEventListener('online',net);window.addEventListener('offline',net);net();
if('serviceWorker'in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}))}renderAll();
